#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int n, minn, maxn;
    cin >> n;
    cin >> minn;
    cin >> maxn;
    if (maxn < minn)
    {
        int temp = maxn;
        maxn = minn;
        minn = temp;
    }
    for (int i = 2; i < n; i++)
    {
        int number;
        cin >> number;
        if (number > maxn)
        {
            maxn = number;
        }
        else if (number < minn)
        {
            minn = number;
        }
    }
    cout << "Min = " << minn << ", Max = " << maxn;
}
