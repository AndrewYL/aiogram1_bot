#include <iostream>

using namespace std;

int main()
{
    int n, sum = 0, a = 1;
    bool b = false;
    cout << "Enter n - ";
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        int number;
        cin >> number;
        if (number == 0 && b == false)
        {
            b = true;
        }
        if (b && number > 0)
        {
            sum += number;
            a *= number;
        }
    }
    cout << "Sum = " << sum << ", Product of numbers = " << a;
}
