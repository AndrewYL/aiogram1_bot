#include <iostream>

using namespace std;

int main()
{
    int x, y;
    cin >> x;
    if (x <= 0)
    {
        y = 0;
    }
    else if (x > 0 && x <= 1)
    {
        y = x;
    }
    else
    {
        y = pow(x, 2);
    }
    cout << "Asnwer: " << y << '\n';
    if (x > 0)
    {
        y = log(x);
    }
    else if (x == 0)
    {
        y = 0;
    }
    else
    {
        y = pow(x, 2);
    }
    cout << "Answer: " << y << '\n';
}
