#include <iostream>

using namespace std;

int main()
{
    double sum1 = 0;
    for (int i = 1; i <= 10; i++)
    {
        int f = 1;
        for (int j = 1; j <= i; j++)
        {
            f *= j;
        }
        if (i % 2 == 1)
        {
            sum1 += 1.0 / f;
        }
        else
        {
            sum1 -= 1.0 / f;
        }
    }
    cout << "sum = " << sum1 << '\n';

    double p = 1;
    for (int i = 1; i <= 8; i++)
    {
        int f = 1;
        double sum2;
        for (int j = 1; j <= i; j++)
        {
            f *= j;
        }
        if (i % 2 == 1)
        {
            sum2 = 1.0 / f;
        }
        else
        {
            sum2 = -1.0 / f;
        }
        p *= (2.0 + sum2);
    }
    cout << "Product = " << p;
}
