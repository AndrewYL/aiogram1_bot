#include <iostream>

using namespace std;

int main()
{
    double n, sum1 = 0, sum2 = 0;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        sum1 += pow(-1, i) / (2 * i + 1);
    }
    cout << "Sum1 = " << sum1 << '\n';
    for (int i = 1; i <= n; i++)
    {
        sum2 += pow(-1, i + 1) / (i * (i + 1));
    }
    cout << "Sum2 = " << sum2;
}
