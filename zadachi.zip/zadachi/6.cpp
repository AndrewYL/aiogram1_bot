#include <iostream>

using namespace std;

int main()
{
    int n, r;
    cin >> N;
    if (n / 100 == 0)
    {
        r = n / 10 + n % 10;
    }
    else
    {
        r = n / 100;
        if (n / 10 % 10 != 0)
        {
            r *= n / 10 % 10;
        }
        if (n % 10 != 0)
        {
            r *= n % 10;
        }
    }
    cout << r;
}
