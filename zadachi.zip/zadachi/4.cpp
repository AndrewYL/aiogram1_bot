#include <iostream>

using namespace std;

int main()
{
    int x, y, r;
    cin >> x >> y >> r;
    if (pow(x, 2) + pow(y, 2) < pow(r, 2))
        cout << "Inside";
    else if (pow(x, 2) + pow(y, 2) > pow(r, 2) && pow(x, 2) + pow(y, 2) < pow(2 * r, 2))
        cout << "Inside r and 2r";
    else
        cout << "Outside";
}
