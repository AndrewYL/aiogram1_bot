#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int sumd = 0;
    for (int i = 1; i <= n / 2; i++)
    {
        if (!(n % i))
        {
            sumd += i;
        }
    }
    if (sumd == n)
    {
        cout << n << " is perfect";
    }
    else
    {
        cout << n << " is not perfect";
    }
}
