#include <iostream>

using namespace std;

int main()
{
    double x, y;
    cin >> x >> y;
    int quart;
    if (x > 0)
        if (y > 0) quart = 1;
        else quart = 4;
    else
        if (y > 0) quart = 2;
        else quart = 3;
    cout << quart;
}
