#include <iostream>

using namespace std;

int main()
{
    int n11, n2, n3;
    cin >> n1 >> n2 >> n3;
    if (n1 > n2 && n1 > n3) cout << "max = " << n1;
    else if (n2 > n1 && n2 > n3) cout << "max = " << n2;
    else cout << "max = " << n3;
}
