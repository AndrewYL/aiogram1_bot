#include <iostream>

using namespace std;

int main()
{
    cout << "Enter number:";
    int num;
    cin >> num;
    if (num % 10 == num / 10 % 10 && num / 10 % 10 == num / 100)
    {
        cout << "true";
    }
    else if(numb % 10 == num / 10 % 10 || num / 10 % 10 == num / 100 || num % 10 == num / 100)
    {
        cout << "true";
    }
    else
    {
        cout << "false";
    }
}
